#include "ParticleLogger.h"

ParticleLogger::ParticleLogger()
{
}

//void ParticleLogger::NewParticleEntry(string entryID)
//{
//	particleEntries[entryID] = 0;
//}
//
//int ParticleLogger::NewParticleEntrySetAmount(string entryID, int amount)
//{
//	if (Contains(entryID)) {
//		cout << "Particle Entries already contain id '" << entryID << "'!" << endl;
//		return GetParticleEntry(entryID);
//	}
//
//	particleEntries[entryID] = amount;
//	return GetParticleEntry(entryID);
//}
//
//int ParticleLogger::GetParticleEntry(string entryID)
//{
//	return particleEntries[entryID];
//}
//
//void ParticleLogger::SetParticleEnrty(string entryID, int amount)
//{
//	particleEntries[entryID] = amount;
//}
//
//int ParticleLogger::IncrementParticleEntry(string entryID)
//{
//	return particleEntries[entryID]++;
//}
//
//int ParticleLogger::IncrementParticleEntrySetAmount(string entryID, int amount)
//{
//	return particleEntries[entryID] += amount;
//}
//
//bool ParticleLogger::Empty()
//{
//	return particleEntries.empty();
//}
//
//int ParticleLogger::TotalEntries()
//{
//	return particleEntries.size();
//}
//
//bool ParticleLogger::Contains(string entryID)
//{
//	return particleEntries.count(entryID);
//}
//
//void ParticleLogger::RecordStatsToFile(string filePath)
//{
//	ofstream myfile;
//	myfile.open(filePath, ios::app);
//
//	// writes current date and time to file 
//	time_t result = time(NULL);
//	char str[26];
//	ctime_s(str, sizeof str, &result);
//	myfile << ("%s", str);
//
//	for (const auto& kv : particleEntries) {
//		myfile << "Particle ID: " << kv.first << ", Amount: " << kv.second << "\n";
//	}
//
//	myfile << "-\n";
//
//	myfile.close();
//}
//
//void ParticleLogger::ClearStatFile(string filePath)
//{
//	ofstream myfile;
//	myfile.open(filePath);
//
//	myfile << "";
//
//	myfile.close();
//}


void ParticleLogger::SetParticleArray(int index, int amount)
{
	particleArray[index] = amount;
}

int ParticleLogger::GetParticleArray(int index)
{
	return particleArray[index];
}

void ParticleLogger::RecordArrayToFile(string filePath)
{
	ofstream myfile;
	myfile.open(filePath, ios::app);

	// writes current date and time to file 
	time_t result = time(NULL);
	char str[26];
	ctime_s(str, sizeof str, &result);
	myfile << ("%s", str);

	for (int x = 0; 20; ++x) // what is lenght?
	{
		myfile << "Amount: " << particleArray[x] << "\n";
	}

	myfile << "-\n";

	myfile.close();
}