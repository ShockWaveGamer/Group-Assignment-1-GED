#pragma once

#ifndef __Particle_Logger__
#define __Particle_Logger__

#include "PluginSettings.h"
#include <iostream>
#include <fstream>
#include <map>
#include <chrono>
#include <ctime> 
using namespace std;

class PLUGIN_API ParticleLogger
{
public:
	ParticleLogger();

	/*void NewParticleEntry(string entryID);
	int NewParticleEntrySetAmount(string entryID, int amount);

	int GetParticleEntry(string entryID);
	void SetParticleEnrty(string entryID, int amount);

	int IncrementParticleEntry(string entryID);
	int IncrementParticleEntrySetAmount(string entryID, int amount);

	bool Empty();
	int TotalEntries();
	bool Contains(string entryID);

	void RecordStatsToFile(string filePath);
	void ClearStatFile(string filePath);*/

	void SetParticleArray(int index, int amount);
	int GetParticleArray(int index);
	void RecordArrayToFile(string filePath);

private:
	//map<string, int> particleEntries;
	int particleArray[];
};

#endif