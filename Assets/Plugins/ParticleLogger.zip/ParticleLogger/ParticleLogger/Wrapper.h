#pragma once

#ifndef __WRAPPER__
#define __WRAPPER__

#include "PluginSettings.h"
#include <iostream>
using namespace std;

#ifdef __cplusplus
extern "C"
{
#endif

	/*PLUGIN_API void NewParticleEntry(string entryID);
	PLUGIN_API int NewParticleEntrySetAmount(string entryID, int amount);

	PLUGIN_API int GetParticleEntry(string entryID);
	PLUGIN_API void SetParticleEnrty(string entryID, int amount);

	PLUGIN_API int IncrementParticleEntry(string entryID);
	PLUGIN_API int IncrementParticleEntrySetAmount(string entryID, int amount);

	PLUGIN_API bool Empty();
	PLUGIN_API int TotalEntries();
	PLUGIN_API bool Contains(string entryID);

	PLUGIN_API void RecordStatsToFile(string filePath);
	PLUGIN_API void ClearStatFile(string filePath);*/

	PLUGIN_API void SetParticleArray(int index, int amount);
	PLUGIN_API int GetParticleArray(int index);
	PLUGIN_API void RecordArrayToFile(string filePath);

#ifndef _cplusplus
}
#endif // !_cplusplus

#endif