#include "Wrapper.h"
#include "ParticleLogger.h"

ParticleLogger logger;

//void NewParticleEntry(string entryID)
//{
//	logger.NewParticleEntry(entryID);
//}
//
//int NewParticleEntrySetAmount(string entryID, int amount)
//{
//	return logger.NewParticleEntrySetAmount(entryID, amount);
//}
//
//int GetParticleEntry(string entryID)
//{
//	return logger.GetParticleEntry(entryID);
//}
//
//void SetParticleEnrty(string entryID, int amount)
//{
//	logger.SetParticleEnrty(entryID, amount);
//}
//
//int IncrementParticleEntry(string entryID)
//{
//	return logger.IncrementParticleEntry(entryID);
//}
//
//int IncrementParticleEntrySetAmount(string entryID, int amount)
//{
//	return logger.IncrementParticleEntrySetAmount(entryID, amount);
//}
//
//bool Empty()
//{
//	return logger.Empty();
//}
//
//int TotalEntries()
//{
//	return logger.TotalEntries();
//}
//
//bool Contains(string entryID)
//{
//	return logger.Contains(entryID);
//}
//
//void RecordStatsToFile(string filePath)
//{
//	logger.RecordStatsToFile(filePath);
//}
//
//void ClearStatFile(string filePath)
//{
//	logger.ClearStatFile(filePath);
//}

void SetParticleArray(int index, int amount)
{
	logger.SetParticleArray(index, amount);
}

int GetParticleArray(int index)
{
	return logger.GetParticleArray(index);
}

void RecordArrayToFile(string filePath)
{
	logger.RecordArrayToFile(filePath);
}
